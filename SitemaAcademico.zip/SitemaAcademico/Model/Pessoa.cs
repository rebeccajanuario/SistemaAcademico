﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaAcademico.Model
{
    class Pessoa
    {
        //Atributos - Variáveis de Classe
        public long cpf;
        public string nome;
        public DateTime dataNascimento;
    }
}
